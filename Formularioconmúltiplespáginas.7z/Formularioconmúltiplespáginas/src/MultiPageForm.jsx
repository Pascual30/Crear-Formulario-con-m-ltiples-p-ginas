import { useState } from "react";

// --- Datos iniciales ---
const initialData = {
  persona: {
    nombre: "",
    apellido: "",
    cedula: "",
    telefono: "",
  },
  familiares: [],
  condiciones: [],
  internamientos: [],
};

export default function MultiPageForm() {
  const [page, setPage] = useState(1);
  const [data, setData] = useState(initialData);

  const next = () => setPage((p) => p + 1);
  const prev = () => setPage((p) => p - 1);

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      {page === 1 && <Pagina1 data={data} setData={setData} />}
      {page === 2 && <Pagina2 data={data} setData={setData} />}
      {page === 3 && <Pagina3 data={data} setData={setData} />}
      {page === 4 && <Pagina4 data={data} setData={setData} />}
      {page === 5 && <Pagina5 data={data} />}

      <div className="flex justify-between">
        {page > 1 && <button onClick={prev} className="px-4 py-2 bg-gray-300 rounded">Anterior</button>}
        {page < 5 && <button onClick={next} className="px-4 py-2 bg-blue-600 text-white rounded">Siguiente</button>}
      </div>
    </div>
  );
}

// --- Página 1: Datos personales ---
function Pagina1({ data, setData }) {
  const persona = data.persona;

  const update = (field, value) => {
    setData({ ...data, persona: { ...persona, [field]: value } });
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Página 1: Datos Personales</h2>
      <input placeholder="Nombre" value={persona.nombre} onChange={(e) => update("nombre", e.target.value)} className="input" />
      <input placeholder="Apellido" value={persona.apellido} onChange={(e) => update("apellido", e.target.value)} className="input" />
      <input placeholder="Cédula" value={persona.cedula} onChange={(e) => update("cedula", e.target.value)} className="input" />
      <input placeholder="Teléfono" value={persona.telefono} onChange={(e) => update("telefono", e.target.value)} className="input" />
    </div>
  );
}

// --- Página 2: Familiares ---
function Pagina2({ data, setData }) {
  const [fam, setFam] = useState({ nombre: "", parentesco: "", edad: "" });

  const agregar = () => {
    if (!fam.nombre || !fam.parentesco || !fam.edad) return;
    setData({ ...data, familiares: [...data.familiares, fam] });
    setFam({ nombre: "", parentesco: "", edad: "" });
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Página 2: Familiares</h2>
      <input placeholder="Nombre" value={fam.nombre} onChange={(e) => setFam({ ...fam, nombre: e.target.value })} className="input" />
      <input placeholder="Parentesco" value={fam.parentesco} onChange={(e) => setFam({ ...fam, parentesco: e.target.value })} className="input" />
      <input placeholder="Edad" value={fam.edad} onChange={(e) => setFam({ ...fam, edad: e.target.value })} className="input" />
      <button onClick={agregar} className="px-4 py-2 bg-green-600 text-white rounded">Agregar Familiar</button>

      <ul className="list-disc ml-6">
        {data.familiares.map((f, i) => (
          <li key={i}>{f.nombre} / {f.parentesco} / {f.edad}</li>
        ))}
      </ul>
    </div>
  );
}

// --- Página 3: Condiciones Pre-existentes ---
function Pagina3({ data, setData }) {
  const [cond, setCond] = useState({ enfermedad: "", tiempo: "" });

  const agregar = () => {
    if (!cond.enfermedad || !cond.tiempo) return;
    setData({ ...data, condiciones: [...data.condiciones, cond] });
    setCond({ enfermedad: "", tiempo: "" });
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Página 3: Condiciones Pre-Existentes</h2>
      <input placeholder="Enfermedad" value={cond.enfermedad} onChange={(e) => setCond({ ...cond, enfermedad: e.target.value })} className="input" />
      <input placeholder="Tiempo con la enfermedad" value={cond.tiempo} onChange={(e) => setCond({ ...cond, tiempo: e.target.value })} className="input" />
      <button onClick={agregar} className="px-4 py-2 bg-green-600 text-white rounded">Agregar Condición</button>

      <ul className="list-disc ml-6">
        {data.condiciones.map((c, i) => (
          <li key={i}>{c.enfermedad} — {c.tiempo}</li>
        ))}
      </ul>
    </div>
  );
}

// --- Página 4: Internamientos ---
function Pagina4({ data, setData }) {
  const [intn, setIntn] = useState({ fecha: "", centro: "", diagnostico: "" });

  const agregar = () => {
    if (!intn.fecha || !intn.centro || !intn.diagnostico) return;
    setData({ ...data, internamientos: [...data.internamientos, intn] });
    setIntn({ fecha: "", centro: "", diagnostico: "" });
  };

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-semibold">Página 4: Internamientos</h2>
      <input type="date" value={intn.fecha} onChange={(e) => setIntn({ ...intn, fecha: e.target.value })} className="input" />
      <input placeholder="Centro Médico" value={intn.centro} onChange={(e) => setIntn({ ...intn, centro: e.target.value })} className="input" />
      <input placeholder="Diagnóstico" value={intn.diagnostico} onChange={(e) => setIntn({ ...intn, diagnostico: e.target.value })} className="input" />
      <button onClick={agregar} className="px-4 py-2 bg-green-600 text-white rounded">Agregar Internamiento</button>

      <ul className="list-disc ml-6">
        {data.internamientos.map((i, idx) => (
          <li key={idx}>{i.fecha} — {i.centro} — {i.diagnostico}</li>
        ))}
      </ul>
    </div>
  );
}

// --- Página 5: Presentación Final de los Datos ---
function Pagina5({ data }) {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Página 5: Datos Registrados</h2>

      <section>
        <h3 className="font-bold">Datos Personales</h3>
        <pre>{JSON.stringify(data.persona, null, 2)}</pre>
      </section>

      <section>
        <h3 className="font-bold">Familiares</h3>
        <pre>{JSON.stringify(data.familiares, null, 2)}</pre>
      </section>

      <section>
        <h3 className="font-bold">Condiciones Pre-existentes</h3>
        <pre>{JSON.stringify(data.condiciones, null, 2)}</pre>
      </section>

      <section>
        <h3 className="font-bold">Internamientos</h3>
        <pre>{JSON.stringify(data.internamientos, null, 2)}</pre>
      </section>
    </div>
  );
}

