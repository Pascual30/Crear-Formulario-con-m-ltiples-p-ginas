import MultiPageForm from "./MultiPageForm";

export default function App() {
  return (
    <div>
      <MultiPageForm />
    </div>
  );
}
